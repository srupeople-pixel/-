extends CanvasLayer
# StatsHUD.gd
# 경험치·엽전 상시 표시 HUD 및 획득량 팝업 텍스트 처리
# PlayerData 시그널(exp_gained, coin_gained)을 수신하여 동작한다.

# ==========================================
# 노드 참조
# ==========================================
@onready var lbl_level   : Label     = $HUDPanel/HUDLayout/LevelRow/LblLevel
@onready var lbl_exp     : Label     = $HUDPanel/HUDLayout/ExpBarRow/LblExp
@onready var exp_bar_bg  : PanelContainer = $HUDPanel/HUDLayout/ExpBarRow/ExpBarBG
@onready var exp_bar_fill: ColorRect = $HUDPanel/HUDLayout/ExpBarRow/ExpBarBG/ExpBarFill
@onready var lbl_coin    : Label     = $HUDPanel/HUDLayout/CoinRow/LblCoin

@onready var popup_exp  : Label = $PopupLayer/PopupContainer/PopupExp
@onready var popup_coin : Label = $PopupLayer/PopupContainer/PopupCoin

# ==========================================
# 팝업 설정
# ==========================================
const POPUP_RISE_PX   : float = 40.0   # 팝업이 위로 올라가는 픽셀
const POPUP_DURATION  : float = 1.2    # 팝업 전체 지속 시간(초)
const POPUP_FADE_START: float = 0.6    # 이 시간 이후부터 투명해지기 시작

# 팝업 누적 오프셋 (여러 보상이 겹치지 않도록 살짝 엇갈리게)
var _exp_popup_offset : float = 0.0
var _coin_popup_offset: float = 0.0

# ==========================================
# 내장 콜백
# ==========================================

func _ready() -> void:
	# PlayerData 시그널 연결
	PlayerData.exp_gained.connect(_on_exp_gained)
	PlayerData.coin_gained.connect(_on_coin_gained)
	# 초기 HUD 갱신
	_refresh_hud()

func _process(_delta: float) -> void:
	_refresh_hud()

# ==========================================
# HUD 갱신
# ==========================================

func _refresh_hud() -> void:
	var lv    : int = PlayerData.level
	var exp   : int = PlayerData.experience
	var req   : int = PlayerData.exp_required_for_level(lv)

	lbl_level.text = str(lv)
	lbl_exp.text   = "%d / %d EXP" % [exp, req]
	lbl_coin.text  = _format_number(PlayerData.coin)

	# 경험치 바 채움 비율 계산 (0.0 ~ 1.0)
	var ratio : float = clampf(float(exp) / float(req), 0.0, 1.0)
	var bar_width : float = exp_bar_bg.size.x * ratio
	exp_bar_fill.size.x = bar_width

# ==========================================
# 팝업 텍스트 (Tween 기반 플로팅 애니메이션)
# ==========================================

## 경험치 획득 시그널 수신 → 팝업 표시
func _on_exp_gained(amount: int) -> void:
	popup_exp.text = "+%d EXP" % amount
	_play_popup(popup_exp, _exp_popup_offset)
	_exp_popup_offset = fmod(_exp_popup_offset + 16.0, 48.0)

## 엽전 획득 시그널 수신 → 팝업 표시
func _on_coin_gained(amount: int) -> void:
	popup_coin.text = "+%d 엽전" % amount
	_play_popup(popup_coin, _coin_popup_offset)
	_coin_popup_offset = fmod(_coin_popup_offset + 16.0, 48.0)

## 팝업 레이블에 위로 올라가며 사라지는 Tween 애니메이션을 적용한다.
func _play_popup(lbl: Label, y_offset: float) -> void:
	# 시작 위치 초기화
	var start_y : float = lbl.position.y + y_offset
	lbl.position.y = start_y
	lbl.modulate.a = 1.0
	lbl.visible    = true

	var tween := create_tween()
	tween.set_parallel(true)

	# 위로 올라가는 이동
	tween.tween_property(lbl, "position:y", start_y - POPUP_RISE_PX, POPUP_DURATION)\
		.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)

	# POPUP_FADE_START 이후부터 투명해짐
	tween.tween_property(lbl, "modulate:a", 0.0, POPUP_DURATION - POPUP_FADE_START)\
		.set_delay(POPUP_FADE_START)\
		.set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_LINEAR)

	# 애니메이션 완료 후 숨김
	tween.chain().tween_callback(func(): lbl.visible = false)

# ==========================================
# 유틸리티
# ==========================================

## 큰 숫자를 읽기 쉽게 포맷한다. (예: 12345 → "12,345")
func _format_number(n: int) -> String:
	var s := str(n)
	var result := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		if count > 0 and count % 3 == 0:
			result = "," + result
		result = s[i] + result
		count += 1
	return result
